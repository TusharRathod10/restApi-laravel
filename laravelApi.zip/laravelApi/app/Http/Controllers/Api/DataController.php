<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Data;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DataController extends Controller
{
    // show data
    public function index()
    {
        $data = Data::all();
        if ($data->count() > 0) {
            return response()->json([
                'status' => 200,
                'data' => $data,
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'No Data Found',
            ], 404);
        }
    }

    // insert data
    public function insert_data(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'email' => 'required|unique:datas|email',
            'password' => 'required|min:8',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => $validator->messages(),
            ], 422);
        } else {
            $data = Data::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
            ]);
            if ($data) {
                return response()->json([
                    'status' => 200,
                    'data' => "Data Insert Successfully",
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something Went Wrong',
                ], 500);
            }
        }
    }

    // get data
    public function get_data($id)
    {
        $data = Data::find($id);
        if ($data) {
            return response()->json([
                'status' => 200,
                'data' => $data,
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'No Data Found',
            ], 404);
        }
    }

    // edit data
    public function edit_data($id)
    {
        $data = Data::find($id);
        if ($data) {
            return response()->json([
                'status' => 200,
                'data' => $data,
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'No Data Found',
            ], 404);
        }
    }

    // update data
    public function update_data(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => $validator->messages(),
            ], 422);
        } else {
            $data = Data::find($id);
            $data->update([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
            ]);
            if ($data) {
                return response()->json([
                    'status' => 200,
                    'data' => "Data Update Successfully",
                ], 200);
            } else {
                return response()->json([
                    'status' => 404,
                    'message' => 'No Data Found',
                ], 404);
            }
        }
    }

    // delete data
    public function delete_data($id)
    {
        $data = Data::find($id);
        if ($data) {
            $data->delete();
            return response()->json([
                'status' => 200,
                'data' => 'Data Delete Successfully',
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'No Data Found',
            ], 404);
        }
    }
}
